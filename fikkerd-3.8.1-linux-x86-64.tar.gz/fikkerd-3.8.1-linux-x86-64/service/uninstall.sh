#!/bin/sh

echo "un-install fikkerd service ..."

if [ ! -d "/etc/fikkerd" ]; then
    rm -rf "/etc/fikkerd"
fi

if [ -d "/etc/rc.d" ]; then
    rm -rf /etc/rc.d/rc2.d/S88fikkerd
    rm -rf /etc/rc.d/rc3.d/S88fikkerd
    rm -rf /etc/rc.d/rc4.d/S88fikkerd
    rm -rf /etc/rc.d/rc5.d/S88fikkerd
else
    rm -rf /etc/rc2.d/S88fikkerd
    rm -rf /etc/rc3.d/S88fikkerd
    rm -rf /etc/rc4.d/S88fikkerd
    rm -rf /etc/rc5.d/S88fikkerd
fi

rm -rf /etc/init.d/fikkerd

echo "un-install fikkerd service OK!"
