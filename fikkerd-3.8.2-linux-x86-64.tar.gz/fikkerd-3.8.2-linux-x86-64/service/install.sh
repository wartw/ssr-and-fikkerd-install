#!/bin/sh

echo "install fikkerd service ..."

if [ ! -d "/etc/fikkerd" ]; then
    mkdir "/etc/fikkerd"
fi

pwd > "/etc/fikkerd/fikkerd.pwd"

rm -rf /etc/init.d/fikkerd
cp ../bin/fikkerd.service /etc/init.d/fikkerd

if [ -d "/etc/rc.d" ]; then
    rm -rf /etc/rc.d/rc1.d/S88fikkerd
    rm -rf /etc/rc.d/rc2.d/S88fikkerd
    rm -rf /etc/rc.d/rc3.d/S88fikkerd
    rm -rf /etc/rc.d/rc4.d/S88fikkerd
    rm -rf /etc/rc.d/rc5.d/S88fikkerd
    rm -rf /etc/rc.d/rc6.d/S88fikkerd
    ln -s /etc/init.d/fikkerd /etc/rc.d/rc1.d/S88fikkerd
    ln -s /etc/init.d/fikkerd /etc/rc.d/rc2.d/S88fikkerd
    ln -s /etc/init.d/fikkerd /etc/rc.d/rc3.d/S88fikkerd
    ln -s /etc/init.d/fikkerd /etc/rc.d/rc4.d/S88fikkerd
    ln -s /etc/init.d/fikkerd /etc/rc.d/rc5.d/S88fikkerd
    ln -s /etc/init.d/fikkerd /etc/rc.d/rc6.d/S88fikkerd
else
    rm -rf /etc/rc1.d/S88fikkerd
    rm -rf /etc/rc2.d/S88fikkerd
    rm -rf /etc/rc3.d/S88fikkerd
    rm -rf /etc/rc4.d/S88fikkerd
    rm -rf /etc/rc5.d/S88fikkerd
    rm -rf /etc/rc6.d/S88fikkerd
    ln -s /etc/init.d/fikkerd /etc/rc1.d/S88fikkerd
    ln -s /etc/init.d/fikkerd /etc/rc2.d/S88fikkerd
    ln -s /etc/init.d/fikkerd /etc/rc3.d/S88fikkerd
    ln -s /etc/init.d/fikkerd /etc/rc4.d/S88fikkerd
    ln -s /etc/init.d/fikkerd /etc/rc5.d/S88fikkerd
    ln -s /etc/init.d/fikkerd /etc/rc6.d/S88fikkerd
fi

if [ -d "/etc/systemd/system" ]; then
    cp ../bin/fikkerd.systemd /etc/systemd/system/fikkerd.service
	systemctl daemon-reload 1> /dev/null 2> /dev/null
	systemctl enable fikkerd 1> /dev/null 2> /dev/null
fi

echo "install fikkerd service OK!"
